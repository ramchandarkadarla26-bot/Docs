# EDC Data Ingestion Platform — Databricks Apps + Lakebase + Lakeflow Connect + Unity Catalog

Implements the project requirement end-to-end:

```
Databricks App -> Lakebase PostgreSQL -> Lakeflow Connect -> Unity Catalog
                                                    (digital_cro.bronze_edc) -> Silver -> Gold
```

## What's here

| Path | Phase | Purpose |
|---|---|---|
| `sql/01_schema_ddl.sql` | 1 | PostgreSQL DDL for all 15 EDC tables (PK/FK, checks, indexes, audit triggers) |
| `synthetic_data/generate_synthetic_data.py` | 2 | Faker-based synthetic data generator with full referential integrity |
| `databricks_app/` | 3 | Streamlit Databricks App — CRUD, search, dashboards, ingestion trigger |
| `lakeflow_connect/` | 4 | Postgres source setup, DAB pipeline/gateway/job YAML, REST API scripts, monitoring |
| `unity_catalog/` | 5 | Silver (cleansed/deduped) and Gold (business aggregates) Delta Live Tables SQL |

Since the requirement doc names the 15 source tables (`o_study`, `o_subject`, etc.)
but doesn't specify columns, I designed a realistic clinical-trial/CDMS schema
for them — see the header comment in `sql/01_schema_ddl.sql` for the entity
relationships. Adjust columns/constraints to match your actual EDC data model
if this was derived from a specific source system.

## Deployment order

### 1. Create the schema in Lakebase
You said the Lakebase Postgres database is already created. Connect to it (via
`psql`, DataGrip, or the Lakebase SQL editor in the workspace) and run:
```bash
psql "host=<lakebase-host> port=5432 dbname=<db> user=<user> sslmode=require" \
  -f sql/01_schema_ddl.sql
```

### 2. Generate synthetic data
```bash
cd synthetic_data
pip install -r requirements.txt
export LAKEBASE_HOST=<host> LAKEBASE_PORT=5432 LAKEBASE_DB=<db> \
       LAKEBASE_USER=<user> LAKEBASE_PASSWORD=<password>
python generate_synthetic_data.py --studies 3 --sites-per-study 4 --subjects-per-site 30
```

### 3. Set up PostgreSQL for Lakeflow Connect ingestion
Run `lakeflow_connect/postgres_source_setup.sql` as an admin (creates the
`databricks_replication` user, publication, and confirms logical replication).
Store its password in a Databricks secret scope:
```bash
databricks secrets create-scope edc-app-secrets
databricks secrets put-secret edc-app-secrets pg-replication-password
```

### 4. Create the Lakeflow Connect connection + gateway + pipeline
Either deploy the Asset Bundle:
```bash
databricks bundle deploy -t dev
databricks bundle run edc_ingestion_pipeline -t dev
```
or run the equivalent script directly against the REST API:
```bash
cd lakeflow_connect
pip install -r requirements.txt
export DATABRICKS_HOST=https://<workspace>.cloud.databricks.com
export DATABRICKS_TOKEN=<pat-or-service-principal-token>
python create_pipeline_rest_api.py \
  --pg-host <lakebase-host> --pg-database <db> \
  --pg-password-secret-scope edc-app-secrets --pg-password-secret-key pg-replication-password \
  --target-catalog digital_cro --target-schema bronze_edc
```
This prints the `ingestion_pipeline_id` — use it for the app's
`LAKEFLOW_PIPELINE_ID` and for `monitor_pipeline.py`.

### 5. Deploy the Silver + Gold Delta Live Tables pipeline
Create a Lakeflow Declarative Pipeline (DLT) in the workspace pointing at
`unity_catalog/silver_transformations.sql` and `unity_catalog/gold_aggregations.sql`
as its source notebooks/files, targeting `digital_cro`.

### 6. Deploy the Databricks App
```bash
cd databricks_app
databricks apps create edc-ops-app
databricks sync . /Workspace/Users/<you>/edc-ops-app
databricks apps deploy edc-ops-app --source-code-path /Workspace/Users/<you>/edc-ops-app
```
In the workspace UI, attach the Lakebase database as an **App resource** so
`PGHOST/PGPORT/PGDATABASE/PGUSER/PGPASSWORD` are injected automatically, and
set `LAKEFLOW_PIPELINE_ID` + the `DATABRICKS_TOKEN` secret reference in `app.yaml`.

## Future enhancements (per requirement doc)
CDC-based incremental Silver merges, data-quality expectations/alerting,
Unity Catalog lineage review, AI/BI dashboards on the Gold layer, and
proactive pipeline monitoring/alerting are natural next steps — the
`lakeflow_connect/monitor_pipeline.py` script and Gold materialized views
are a starting point for the monitoring and dashboard pieces.

## Notes / assumptions
- Lakeflow Connect's PostgreSQL connector is a managed CDC connector (gateway +
  ingestion pipeline pair); it is not a single simple REST call, so both a
  declarative (Asset Bundle YAML) and a scripted (SDK/REST) path are provided.
- The Databricks App uses Streamlit; swap for Dash/Flask/Gradio if preferred —
  `db.py` is framework-agnostic.
- Passwords/tokens are referenced via Databricks secret scopes, never hardcoded.
