"""
Phase 2 — Synthetic EDC data generator.

Generates realistic, referentially-consistent clinical trial data and loads it
directly into the Lakebase PostgreSQL OLTP schema (edc.*) created by
sql/01_schema_ddl.sql.

Generation order follows FK dependency order:
  o_study -> o_protocol_derivation -> o_site -> o_subject -> o_subject_enf
  -> o_study_event -> o_study_crf -> o_codelist_item -> o_study_crf_data_item
  -> o_subject_event -> o_subject_crf_data_item -> o_query
  -> o_query_crf_data_items_rel -> o_subject_audit_history -> o_metadata

Usage:
    pip install -r requirements.txt
    export LAKEBASE_HOST=<host>
    export LAKEBASE_PORT=5432
    export LAKEBASE_DB=<database>
    export LAKEBASE_USER=<user>
    export LAKEBASE_PASSWORD=<password>
    python generate_synthetic_data.py --studies 3 --subjects-per-site 40
"""

import argparse
import os
import random
from datetime import date, timedelta

import psycopg2
import psycopg2.extras
from faker import Faker

fake = Faker()
Faker.seed(42)
random.seed(42)

THERAPEUTIC_AREAS = ["Oncology", "Cardiology", "Neurology", "Immunology", "Endocrinology"]
PHASES = ["I", "II", "III", "IV"]
COUNTRIES = ["United States", "Germany", "India", "Japan", "Brazil", "Canada", "United Kingdom"]
EVENT_NAMES = ["Screening", "Baseline", "Week 4", "Week 8", "Week 12", "Week 24", "End of Study", "Unscheduled Visit"]
CRF_NAMES = ["Demographics", "Vital Signs", "Adverse Events", "Concomitant Medications",
             "Laboratory Results", "Physical Exam", "Efficacy Assessment", "Medical History"]
ITEM_CATALOG = {
    "Demographics": [("AGE", "Age", "NUMBER"), ("RACE", "Race", "CODED"), ("ETHNIC", "Ethnicity", "CODED")],
    "Vital Signs": [("SYSBP", "Systolic BP (mmHg)", "NUMBER"), ("DIABP", "Diastolic BP (mmHg)", "NUMBER"),
                    ("HR", "Heart Rate (bpm)", "NUMBER"), ("TEMP", "Temperature (C)", "NUMBER")],
    "Adverse Events": [("AETERM", "Adverse Event Term", "TEXT"), ("AESEV", "Severity", "CODED"),
                        ("AESER", "Serious", "BOOLEAN")],
    "Concomitant Medications": [("CMTRT", "Medication Name", "TEXT"), ("CMDOSE", "Dose", "TEXT")],
    "Laboratory Results": [("LBTEST", "Lab Test", "CODED"), ("LBORRES", "Result Value", "NUMBER")],
    "Physical Exam": [("PEFIND", "Finding", "TEXT")],
    "Efficacy Assessment": [("EFSCORE", "Efficacy Score", "NUMBER")],
    "Medical History": [("MHTERM", "Medical History Term", "TEXT")],
}
CODELISTS = {
    "RACE": ["White", "Black or African American", "Asian", "Other"],
    "ETHNIC": ["Hispanic or Latino", "Not Hispanic or Latino"],
    "AESEV": ["MILD", "MODERATE", "SEVERE"],
    "LBTEST": ["Hemoglobin", "WBC Count", "Platelet Count", "ALT", "AST", "Creatinine"],
}
QUERY_REASONS = [
    "Value out of expected range, please confirm.",
    "Missing required field, please complete.",
    "Inconsistent date with visit schedule.",
    "Please clarify units of measure.",
]


def get_connection():
    return psycopg2.connect(
        host=os.environ.get("LAKEBASE_HOST", "localhost"),
        port=os.environ.get("LAKEBASE_PORT", "5432"),
        dbname=os.environ.get("LAKEBASE_DB", "postgres"),
        user=os.environ.get("LAKEBASE_USER", "postgres"),
        password=os.environ.get("LAKEBASE_PASSWORD", ""),
        sslmode=os.environ.get("LAKEBASE_SSLMODE", "require"),
    )


def insert_returning_id(cur, sql, params):
    cur.execute(sql, params)
    return cur.fetchone()[0]


def generate(conn, n_studies, sites_per_study, subjects_per_site):
    cur = conn.cursor()

    # 1. Seed codelist items -------------------------------------------------
    for codelist_name, values in CODELISTS.items():
        for i, val in enumerate(values):
            cur.execute(
                """INSERT INTO edc.o_codelist_item (codelist_name, code_value, code_label, sort_order)
                   VALUES (%s, %s, %s, %s) ON CONFLICT (codelist_name, code_value) DO NOTHING""",
                (codelist_name, val.upper().replace(" ", "_"), val, i),
            )

    for s in range(n_studies):
        study_id = insert_returning_id(
            cur,
            """INSERT INTO edc.o_study
               (study_code, protocol_number, study_name, sponsor_name, phase,
                therapeutic_area, indication, planned_start_date, planned_end_date, study_status)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING study_id""",
            (
                f"STUDY-{1000+s}",
                f"PROTO-{2024}-{100+s}",
                f"{random.choice(THERAPEUTIC_AREAS)} Study {s+1}",
                fake.company() + " Pharmaceuticals",
                random.choice(PHASES),
                random.choice(THERAPEUTIC_AREAS),
                fake.catch_phrase(),
                date(2024, 1, 1) + timedelta(days=random.randint(0, 180)),
                date(2026, 12, 31),
                "ACTIVE",
            ),
        )

        # Protocol derivation (version 1.0 + one amendment)
        insert_returning_id(
            cur,
            """INSERT INTO edc.o_protocol_derivation
               (study_id, version_number, amendment_number, effective_date, description, is_current)
               VALUES (%s, %s, %s, %s, %s, %s) RETURNING protocol_derivation_id""",
            (study_id, "1.0", 0, date(2024, 1, 1), "Original protocol", False),
        )
        insert_returning_id(
            cur,
            """INSERT INTO edc.o_protocol_derivation
               (study_id, version_number, amendment_number, effective_date, description, is_current)
               VALUES (%s, %s, %s, %s, %s, %s) RETURNING protocol_derivation_id""",
            (study_id, "1.1", 1, date(2024, 6, 1), "Amendment 1: updated eligibility criteria", True),
        )

        # Study events (schedule of events)
        study_event_ids = {}
        for order, ev_name in enumerate(EVENT_NAMES):
            ev_id = insert_returning_id(
                cur,
                """INSERT INTO edc.o_study_event
                   (study_id, event_name, event_type, event_order, planned_day_offset, is_repeating)
                   VALUES (%s, %s, %s, %s, %s, %s) RETURNING study_event_id""",
                (
                    study_id, ev_name,
                    "UNSCHEDULED" if ev_name == "Unscheduled Visit" else "SCHEDULED",
                    order, order * 28,
                    ev_name == "Unscheduled Visit",
                ),
            )
            study_event_ids[ev_name] = ev_id

        # Study CRFs + data item definitions, linked to relevant events
        crf_data_item_ids = {}  # crf_name -> list of (item_id, item_name, data_type)
        for crf_name in CRF_NAMES:
            linked_event = random.choice([eid for name, eid in study_event_ids.items() if name != "Unscheduled Visit"])
            crf_id = insert_returning_id(
                cur,
                """INSERT INTO edc.o_study_crf (study_id, study_event_id, crf_name, crf_version, is_required)
                   VALUES (%s, %s, %s, %s, %s) RETURNING study_crf_id""",
                (study_id, linked_event, crf_name, "1.0", True),
            )
            items = []
            for order, (item_name, item_label, data_type) in enumerate(ITEM_CATALOG[crf_name]):
                codelist_name = item_name if item_name in CODELISTS else None
                item_id = insert_returning_id(
                    cur,
                    """INSERT INTO edc.o_study_crf_data_item
                       (study_crf_id, item_name, item_label, data_type, codelist_name, is_required, item_order)
                       VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING study_crf_data_item_id""",
                    (crf_id, item_name, item_label, data_type, codelist_name, True, order),
                )
                items.append((item_id, item_name, data_type, codelist_name))
            crf_data_item_ids[crf_name] = items

        # Sites
        for site_num in range(sites_per_study):
            site_id = insert_returning_id(
                cur,
                """INSERT INTO edc.o_site
                   (study_id, site_number, site_name, principal_investigator, country, city, activation_date, site_status)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING site_id""",
                (
                    study_id, f"{100+site_num}", f"{fake.city()} Medical Center",
                    "Dr. " + fake.last_name(), random.choice(COUNTRIES), fake.city(),
                    date(2024, 2, 1), "ACTIVE",
                ),
            )

            # Subjects per site
            for subj_num in range(subjects_per_site):
                dob = fake.date_of_birth(minimum_age=18, maximum_age=85)
                consent_date = date(2024, 3, 1) + timedelta(days=random.randint(0, 300))
                enroll_date = consent_date + timedelta(days=random.randint(1, 14))
                status = random.choices(
                    ["ENROLLED", "RANDOMIZED", "COMPLETED", "WITHDRAWN", "SCREEN_FAILED"],
                    weights=[15, 40, 25, 10, 10],
                )[0]

                subject_id = insert_returning_id(
                    cur,
                    """INSERT INTO edc.o_subject
                       (study_id, site_id, subject_number, date_of_birth, sex, informed_consent_date,
                        enrollment_date, randomization_date, randomization_arm, subject_status)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING subject_id""",
                    (
                        study_id, site_id, f"{100+site_num}-{1000+subj_num}", dob,
                        random.choice(["M", "F"]), consent_date, enroll_date,
                        enroll_date + timedelta(days=3) if status in ("RANDOMIZED", "COMPLETED") else None,
                        random.choice(["Treatment A", "Treatment B", "Placebo"]) if status in ("RANDOMIZED", "COMPLETED") else None,
                        status,
                    ),
                )

                # Eligibility / enrollment form
                eligible = status != "SCREEN_FAILED"
                cur.execute(
                    """INSERT INTO edc.o_subject_enf
                       (subject_id, screening_date, inclusion_criteria_met, exclusion_criteria_met,
                        eligibility_status, screen_failure_reason)
                       VALUES (%s, %s, %s, %s, %s, %s)""",
                    (
                        subject_id, consent_date, eligible, not eligible,
                        "ELIGIBLE" if eligible else "INELIGIBLE",
                        None if eligible else "Did not meet inclusion criteria #3",
                    ),
                )

                # Subject events + captured CRF data for a random subset of visits
                n_visits = random.randint(2, len(EVENT_NAMES) - 1)  # skip Unscheduled by default
                visited_events = random.sample(
                    [n for n in EVENT_NAMES if n != "Unscheduled Visit"], n_visits
                )
                all_captured_item_ids = []
                for ev_name in visited_events:
                    visit_date = enroll_date + timedelta(days=study_event_ids and EVENT_NAMES.index(ev_name) * 28)
                    subj_event_id = insert_returning_id(
                        cur,
                        """INSERT INTO edc.o_subject_event
                           (subject_id, study_event_id, visit_date, actual_day, event_status)
                           VALUES (%s, %s, %s, %s, %s) RETURNING subject_event_id""",
                        (subject_id, study_event_ids[ev_name], visit_date,
                         EVENT_NAMES.index(ev_name) * 28, "COMPLETED"),
                    )

                    # Capture 1-2 CRFs worth of data items per visit
                    for crf_name in random.sample(CRF_NAMES, k=min(2, len(CRF_NAMES))):
                        for item_id, item_name, data_type, codelist_name in crf_data_item_ids[crf_name]:
                            value_text = value_num = value_date = None
                            if data_type == "NUMBER":
                                value_num = round(random.uniform(50, 150), 1)
                            elif data_type == "DATE":
                                value_date = visit_date
                            elif data_type == "CODED" and codelist_name:
                                value_text = random.choice(CODELISTS.get(codelist_name, ["N/A"]))
                            elif data_type == "BOOLEAN":
                                value_text = random.choice(["TRUE", "FALSE"])
                            else:
                                value_text = fake.sentence(nb_words=4)

                            data_item_id = insert_returning_id(
                                cur,
                                """INSERT INTO edc.o_subject_crf_data_item
                                   (subject_id, subject_event_id, study_crf_data_item_id,
                                    item_value_text, item_value_numeric, item_value_date,
                                    entry_status, entered_by)
                                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING subject_crf_data_item_id""",
                                (subject_id, subj_event_id, item_id, value_text, value_num,
                                 value_date, random.choice(["ENTERED", "VERIFIED", "SDV"]), fake.user_name()),
                            )
                            all_captured_item_ids.append(data_item_id)

                # Queries (roughly 1 in 6 data items gets a query)
                for data_item_id in random.sample(all_captured_item_ids, k=max(0, len(all_captured_item_ids) // 6)):
                    query_id = insert_returning_id(
                        cur,
                        """INSERT INTO edc.o_query
                           (subject_id, query_text, query_status, priority, opened_by)
                           VALUES (%s, %s, %s, %s, %s) RETURNING query_id""",
                        (subject_id, random.choice(QUERY_REASONS),
                         random.choice(["OPEN", "ANSWERED", "CLOSED"]),
                         random.choice(["LOW", "MEDIUM", "HIGH"]), fake.user_name()),
                    )
                    cur.execute(
                        """INSERT INTO edc.o_query_crf_data_items_rel (query_id, subject_crf_data_item_id)
                           VALUES (%s, %s)""",
                        (query_id, data_item_id),
                    )

                # Audit trail entry for enrollment
                cur.execute(
                    """INSERT INTO edc.o_subject_audit_history
                       (subject_id, table_name, record_id, field_name, old_value, new_value,
                        action_type, changed_by, reason_for_change)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    (subject_id, "o_subject", subject_id, "subject_status", None, status,
                     "INSERT", fake.user_name(), "Subject enrollment"),
                )

        conn.commit()
        print(f"Study {study_id} generated: {sites_per_study} sites, "
              f"{sites_per_study * subjects_per_site} subjects.")

    # A couple of general metadata rows
    cur.execute(
        """INSERT INTO edc.o_metadata (entity_name, attribute_name, attribute_value, description)
           VALUES (%s, %s, %s, %s) ON CONFLICT (entity_name, attribute_name) DO NOTHING""",
        ("edc_app", "data_generated_date", str(date.today()), "Last synthetic data generation run"),
    )
    conn.commit()
    cur.close()


def main():
    parser = argparse.ArgumentParser(description="Generate synthetic EDC data into Lakebase PostgreSQL.")
    parser.add_argument("--studies", type=int, default=2)
    parser.add_argument("--sites-per-study", type=int, default=3)
    parser.add_argument("--subjects-per-site", type=int, default=20)
    args = parser.parse_args()

    conn = get_connection()
    try:
        generate(conn, args.studies, args.sites_per_study, args.subjects_per_site)
        print("Synthetic data generation complete.")
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    main()
