-- ============================================================================
-- Phase 5 (part 1) — Silver layer
-- Deploy as a Lakeflow Declarative Pipeline (Delta Live Tables) SQL notebook,
-- reading from digital_cro.bronze_edc.* (populated by Lakeflow Connect) and
-- writing cleansed, deduplicated, business-key-enforced tables to
-- digital_cro.silver_edc.
--
-- Bronze tables are append-only replicas of the source Postgres tables, so
-- Silver applies CDC dedup (keep latest per PK) and light typing/quality checks.
-- ============================================================================

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.study
(
  CONSTRAINT valid_study_id EXPECT (study_id IS NOT NULL) ON VIOLATION DROP ROW
)
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_study)
QUALIFY ROW_NUMBER() OVER (PARTITION BY study_id ORDER BY updated_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.site
(
  CONSTRAINT valid_site_id EXPECT (site_id IS NOT NULL) ON VIOLATION DROP ROW,
  CONSTRAINT valid_study_fk EXPECT (study_id IS NOT NULL) ON VIOLATION DROP ROW
)
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_site)
QUALIFY ROW_NUMBER() OVER (PARTITION BY site_id ORDER BY created_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.subject
(
  CONSTRAINT valid_subject_id EXPECT (subject_id IS NOT NULL) ON VIOLATION DROP ROW,
  CONSTRAINT valid_status EXPECT (subject_status IS NOT NULL) ON VIOLATION DROP ROW
)
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_subject)
QUALIFY ROW_NUMBER() OVER (PARTITION BY subject_id ORDER BY updated_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.subject_enf
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_subject_enf)
QUALIFY ROW_NUMBER() OVER (PARTITION BY subject_enf_id ORDER BY created_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.study_event
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_study_event)
QUALIFY ROW_NUMBER() OVER (PARTITION BY study_event_id ORDER BY created_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.subject_event
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_subject_event)
QUALIFY ROW_NUMBER() OVER (PARTITION BY subject_event_id ORDER BY updated_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.study_crf
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_study_crf)
QUALIFY ROW_NUMBER() OVER (PARTITION BY study_crf_id ORDER BY created_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.study_crf_data_item
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_study_crf_data_item)
QUALIFY ROW_NUMBER() OVER (PARTITION BY study_crf_data_item_id ORDER BY created_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.subject_crf_data_item
(
  CONSTRAINT valid_link EXPECT (subject_id IS NOT NULL AND study_crf_data_item_id IS NOT NULL) ON VIOLATION DROP ROW
)
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_subject_crf_data_item)
QUALIFY ROW_NUMBER() OVER (PARTITION BY subject_crf_data_item_id ORDER BY updated_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.codelist_item
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_codelist_item)
QUALIFY ROW_NUMBER() OVER (PARTITION BY codelist_item_id ORDER BY created_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.query
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_query)
QUALIFY ROW_NUMBER() OVER (PARTITION BY query_id ORDER BY opened_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.query_crf_data_items_rel
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_query_crf_data_items_rel)
QUALIFY ROW_NUMBER() OVER (PARTITION BY query_crf_data_items_rel_id ORDER BY created_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.protocol_derivation
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_protocol_derivation)
QUALIFY ROW_NUMBER() OVER (PARTITION BY protocol_derivation_id ORDER BY created_date DESC) = 1;

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.subject_audit_history
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_subject_audit_history);

CREATE OR REFRESH STREAMING TABLE digital_cro.silver_edc.metadata
AS SELECT * EXCEPT (_rescued_data)
FROM STREAM(digital_cro.bronze_edc.o_metadata)
QUALIFY ROW_NUMBER() OVER (PARTITION BY metadata_id ORDER BY created_date DESC) = 1;
