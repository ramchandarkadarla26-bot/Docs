-- ============================================================================
-- Phase 5 (part 2) — Gold layer
-- Business-level aggregates built on top of digital_cro.silver_edc.*, for
-- AI/BI dashboards and downstream reporting. Deploy as materialized views or
-- as additional steps in the same Lakeflow Declarative Pipeline as Silver.
-- ============================================================================

CREATE OR REFRESH MATERIALIZED VIEW digital_cro.gold_edc.enrollment_summary
AS
SELECT
  st.study_id,
  st.study_name,
  si.site_id,
  si.site_name,
  si.country,
  COUNT(sub.subject_id)                                              AS total_subjects,
  COUNT(*) FILTER (WHERE sub.subject_status = 'ENROLLED')            AS enrolled_count,
  COUNT(*) FILTER (WHERE sub.subject_status = 'RANDOMIZED')          AS randomized_count,
  COUNT(*) FILTER (WHERE sub.subject_status = 'COMPLETED')           AS completed_count,
  COUNT(*) FILTER (WHERE sub.subject_status = 'WITHDRAWN')           AS withdrawn_count,
  COUNT(*) FILTER (WHERE sub.subject_status = 'SCREEN_FAILED')       AS screen_failed_count
FROM digital_cro.silver_edc.study st
JOIN digital_cro.silver_edc.site si  ON si.study_id = st.study_id
LEFT JOIN digital_cro.silver_edc.subject sub ON sub.site_id = si.site_id
GROUP BY st.study_id, st.study_name, si.site_id, si.site_name, si.country;

CREATE OR REFRESH MATERIALIZED VIEW digital_cro.gold_edc.query_aging
AS
SELECT
  st.study_id,
  st.study_name,
  q.query_status,
  q.priority,
  COUNT(*)                                                            AS query_count,
  AVG(DATEDIFF(
        COALESCE(q.closed_date, current_timestamp()), q.opened_date
      ))                                                               AS avg_age_days,
  MAX(DATEDIFF(
        COALESCE(q.closed_date, current_timestamp()), q.opened_date
      ))                                                               AS max_age_days
FROM digital_cro.silver_edc.query q
JOIN digital_cro.silver_edc.subject sub ON sub.subject_id = q.subject_id
JOIN digital_cro.silver_edc.study st     ON st.study_id = sub.study_id
GROUP BY st.study_id, st.study_name, q.query_status, q.priority;

CREATE OR REFRESH MATERIALIZED VIEW digital_cro.gold_edc.data_entry_completeness
AS
SELECT
  st.study_id,
  st.study_name,
  scrf.crf_name,
  COUNT(DISTINCT sdi.study_crf_data_item_id)                          AS defined_item_count,
  COUNT(DISTINCT scdi.subject_crf_data_item_id)                       AS captured_item_count,
  COUNT(*) FILTER (WHERE scdi.entry_status = 'VERIFIED')              AS verified_count,
  COUNT(*) FILTER (WHERE scdi.entry_status = 'SDV')                   AS sdv_count
FROM digital_cro.silver_edc.study st
JOIN digital_cro.silver_edc.study_crf scrf              ON scrf.study_id = st.study_id
JOIN digital_cro.silver_edc.study_crf_data_item sdi     ON sdi.study_crf_id = scrf.study_crf_id
LEFT JOIN digital_cro.silver_edc.subject_crf_data_item scdi
       ON scdi.study_crf_data_item_id = sdi.study_crf_data_item_id
GROUP BY st.study_id, st.study_name, scrf.crf_name;

CREATE OR REFRESH MATERIALIZED VIEW digital_cro.gold_edc.subject_audit_rollup
AS
SELECT
  sub.study_id,
  ah.table_name,
  ah.action_type,
  DATE_TRUNC('day', ah.changed_date) AS change_day,
  COUNT(*) AS change_count
FROM digital_cro.silver_edc.subject_audit_history ah
JOIN digital_cro.silver_edc.subject sub ON sub.subject_id = ah.subject_id
GROUP BY sub.study_id, ah.table_name, ah.action_type, DATE_TRUNC('day', ah.changed_date);
