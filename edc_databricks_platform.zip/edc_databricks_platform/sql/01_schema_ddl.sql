-- ============================================================================
-- EDC Data Ingestion Platform — Lakebase PostgreSQL Schema (OLTP layer)
-- Phase 1: DDLs with PK/FK constraints and indexes
--
-- Domain model: standard clinical-trial EDC (CDMS) entities.
-- Naming follows the source table list from the project requirement:
--   o_study, o_subject, o_subject_enf, o_subject_event, o_subject_crf_data_item,
--   o_study_crf, o_study_crf_data_item, o_study_event, o_metadata, o_site,
--   o_codelist_item, o_query, o_protocol_derivation, o_query_crf_data_items_rel,
--   o_subject_audit_history
--
-- Run this against the Lakebase PostgreSQL database/instance you created.
-- ============================================================================

CREATE SCHEMA IF NOT EXISTS edc;
SET search_path TO edc;

-- ----------------------------------------------------------------------------
-- 1. o_study — Study master
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_study (
    study_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    study_code          VARCHAR(32)  NOT NULL UNIQUE,
    protocol_number     VARCHAR(64)  NOT NULL,
    study_name          VARCHAR(255) NOT NULL,
    sponsor_name         VARCHAR(255),
    phase               VARCHAR(16)  CHECK (phase IN ('I','II','III','IV','N/A')),
    therapeutic_area    VARCHAR(128),
    indication          VARCHAR(255),
    planned_start_date  DATE,
    planned_end_date    DATE,
    actual_start_date   DATE,
    actual_end_date     DATE,
    study_status        VARCHAR(32)  NOT NULL DEFAULT 'PLANNED'
                         CHECK (study_status IN ('PLANNED','ACTIVE','SUSPENDED','COMPLETED','TERMINATED')),
    created_by          VARCHAR(64)  NOT NULL DEFAULT CURRENT_USER,
    created_date        TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_date         TIMESTAMPTZ  NOT NULL DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 2. o_protocol_derivation — Protocol versions / amendments for a study
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_protocol_derivation (
    protocol_derivation_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    study_id               BIGINT NOT NULL REFERENCES edc.o_study(study_id) ON DELETE CASCADE,
    version_number         VARCHAR(16) NOT NULL,
    amendment_number       INTEGER DEFAULT 0,
    effective_date         DATE NOT NULL,
    description            TEXT,
    is_current             BOOLEAN NOT NULL DEFAULT TRUE,
    created_date           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (study_id, version_number)
);

-- ----------------------------------------------------------------------------
-- 3. o_site — Investigational sites
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_site (
    site_id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    study_id            BIGINT NOT NULL REFERENCES edc.o_study(study_id) ON DELETE CASCADE,
    site_number         VARCHAR(32) NOT NULL,
    site_name           VARCHAR(255) NOT NULL,
    principal_investigator VARCHAR(255),
    country             VARCHAR(64),
    city                VARCHAR(128),
    activation_date     DATE,
    site_status         VARCHAR(32) NOT NULL DEFAULT 'PENDING'
                         CHECK (site_status IN ('PENDING','ACTIVE','CLOSED','SUSPENDED')),
    created_date        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (study_id, site_number)
);

-- ----------------------------------------------------------------------------
-- 4. o_subject — Enrolled subjects
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_subject (
    subject_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    study_id            BIGINT NOT NULL REFERENCES edc.o_study(study_id) ON DELETE CASCADE,
    site_id             BIGINT NOT NULL REFERENCES edc.o_site(site_id) ON DELETE RESTRICT,
    subject_number      VARCHAR(32) NOT NULL,
    date_of_birth       DATE,
    sex                 VARCHAR(1) CHECK (sex IN ('M','F','U')),
    informed_consent_date DATE,
    enrollment_date     DATE,
    randomization_date  DATE,
    randomization_arm   VARCHAR(64),
    subject_status      VARCHAR(32) NOT NULL DEFAULT 'SCREENING'
                         CHECK (subject_status IN ('SCREENING','SCREEN_FAILED','ENROLLED','RANDOMIZED','COMPLETED','WITHDRAWN','DISCONTINUED')),
    created_date        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_date        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (study_id, subject_number)
);

-- ----------------------------------------------------------------------------
-- 5. o_subject_enf — Subject eligibility / enrollment form (screening outcome)
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_subject_enf (
    subject_enf_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    subject_id          BIGINT NOT NULL REFERENCES edc.o_subject(subject_id) ON DELETE CASCADE,
    screening_date      DATE NOT NULL,
    inclusion_criteria_met BOOLEAN NOT NULL DEFAULT TRUE,
    exclusion_criteria_met BOOLEAN NOT NULL DEFAULT FALSE,
    eligibility_status  VARCHAR(16) NOT NULL DEFAULT 'ELIGIBLE'
                         CHECK (eligibility_status IN ('ELIGIBLE','INELIGIBLE','PENDING')),
    screen_failure_reason TEXT,
    created_date        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (subject_id)
);

-- ----------------------------------------------------------------------------
-- 6. o_study_event — Study-level visit/event definitions (schedule of events)
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_study_event (
    study_event_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    study_id            BIGINT NOT NULL REFERENCES edc.o_study(study_id) ON DELETE CASCADE,
    event_name          VARCHAR(128) NOT NULL,
    event_type          VARCHAR(32) NOT NULL DEFAULT 'SCHEDULED'
                         CHECK (event_type IN ('SCHEDULED','UNSCHEDULED','COMMON')),
    event_order         INTEGER NOT NULL,
    planned_day_offset  INTEGER,
    is_repeating        BOOLEAN NOT NULL DEFAULT FALSE,
    created_date        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (study_id, event_name)
);

-- ----------------------------------------------------------------------------
-- 7. o_study_crf — CRF (form) definitions, attached to a study event
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_study_crf (
    study_crf_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    study_id            BIGINT NOT NULL REFERENCES edc.o_study(study_id) ON DELETE CASCADE,
    study_event_id      BIGINT REFERENCES edc.o_study_event(study_event_id) ON DELETE SET NULL,
    crf_name            VARCHAR(128) NOT NULL,
    crf_version         VARCHAR(16) NOT NULL DEFAULT '1.0',
    crf_type            VARCHAR(32) DEFAULT 'STANDARD',
    is_required         BOOLEAN NOT NULL DEFAULT TRUE,
    created_date        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (study_id, crf_name, crf_version)
);

-- ----------------------------------------------------------------------------
-- 8. o_codelist_item — Controlled-terminology / dictionary values
--    (defined before o_study_crf_data_item, which references it)
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_codelist_item (
    codelist_item_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codelist_name        VARCHAR(128) NOT NULL,
    code_value           VARCHAR(64) NOT NULL,
    code_label           VARCHAR(255) NOT NULL,
    sort_order           INTEGER DEFAULT 0,
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,
    created_date          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (codelist_name, code_value)
);

-- ----------------------------------------------------------------------------
-- 9. o_study_crf_data_item — Field/item definitions (metadata) within a CRF
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_study_crf_data_item (
    study_crf_data_item_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    study_crf_id           BIGINT NOT NULL REFERENCES edc.o_study_crf(study_crf_id) ON DELETE CASCADE,
    item_name              VARCHAR(128) NOT NULL,
    item_label             VARCHAR(255) NOT NULL,
    data_type              VARCHAR(16) NOT NULL DEFAULT 'TEXT'
                            CHECK (data_type IN ('TEXT','NUMBER','DATE','CODED','BOOLEAN')),
    codelist_name          VARCHAR(128),
    is_required            BOOLEAN NOT NULL DEFAULT FALSE,
    item_order             INTEGER NOT NULL DEFAULT 0,
    validation_rule        VARCHAR(255),
    created_date           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (study_crf_id, item_name)
);

-- ----------------------------------------------------------------------------
-- 10. o_subject_event — Subject's actual occurrences of study events/visits
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_subject_event (
    subject_event_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    subject_id          BIGINT NOT NULL REFERENCES edc.o_subject(subject_id) ON DELETE CASCADE,
    study_event_id      BIGINT NOT NULL REFERENCES edc.o_study_event(study_event_id) ON DELETE RESTRICT,
    visit_date          DATE,
    actual_day          INTEGER,
    event_status        VARCHAR(32) NOT NULL DEFAULT 'SCHEDULED'
                         CHECK (event_status IN ('SCHEDULED','IN_PROGRESS','COMPLETED','MISSED','NOT_DONE')),
    created_date        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_date        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 11. o_subject_crf_data_item — Actual captured EDC data values (core transactional table)
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_subject_crf_data_item (
    subject_crf_data_item_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    subject_id               BIGINT NOT NULL REFERENCES edc.o_subject(subject_id) ON DELETE CASCADE,
    subject_event_id         BIGINT NOT NULL REFERENCES edc.o_subject_event(subject_event_id) ON DELETE CASCADE,
    study_crf_data_item_id   BIGINT NOT NULL REFERENCES edc.o_study_crf_data_item(study_crf_data_item_id) ON DELETE RESTRICT,
    item_value_text          TEXT,
    item_value_numeric       NUMERIC(18,4),
    item_value_date          DATE,
    entry_status             VARCHAR(16) NOT NULL DEFAULT 'ENTERED'
                              CHECK (entry_status IN ('ENTERED','VERIFIED','LOCKED','FROZEN','SDV')),
    entered_by                VARCHAR(64),
    entered_date               TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_date               TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 12. o_query — Data management queries raised against captured data
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_query (
    query_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    subject_id          BIGINT NOT NULL REFERENCES edc.o_subject(subject_id) ON DELETE CASCADE,
    query_text          TEXT NOT NULL,
    query_status        VARCHAR(16) NOT NULL DEFAULT 'OPEN'
                         CHECK (query_status IN ('OPEN','ANSWERED','CLOSED','CANCELLED')),
    priority            VARCHAR(16) NOT NULL DEFAULT 'MEDIUM'
                         CHECK (priority IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    opened_by           VARCHAR(64) NOT NULL,
    opened_date         TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_by           VARCHAR(64),
    closed_date         TIMESTAMPTZ
);

-- ----------------------------------------------------------------------------
-- 13. o_query_crf_data_items_rel — Many-to-many: which data items a query concerns
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_query_crf_data_items_rel (
    query_crf_data_items_rel_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    query_id                    BIGINT NOT NULL REFERENCES edc.o_query(query_id) ON DELETE CASCADE,
    subject_crf_data_item_id    BIGINT NOT NULL REFERENCES edc.o_subject_crf_data_item(subject_crf_data_item_id) ON DELETE CASCADE,
    created_date                TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (query_id, subject_crf_data_item_id)
);

-- ----------------------------------------------------------------------------
-- 14. o_subject_audit_history — Generic audit trail (21 CFR Part 11 style)
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_subject_audit_history (
    audit_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    subject_id          BIGINT NOT NULL REFERENCES edc.o_subject(subject_id) ON DELETE CASCADE,
    table_name          VARCHAR(64) NOT NULL,
    record_id           BIGINT NOT NULL,
    field_name          VARCHAR(128),
    old_value           TEXT,
    new_value           TEXT,
    action_type         VARCHAR(16) NOT NULL CHECK (action_type IN ('INSERT','UPDATE','DELETE')),
    changed_by          VARCHAR(64) NOT NULL,
    changed_date        TIMESTAMPTZ NOT NULL DEFAULT now(),
    reason_for_change   TEXT
);

-- ----------------------------------------------------------------------------
-- 15. o_metadata — Generic key/value metadata store for app + reference config
-- ----------------------------------------------------------------------------
CREATE TABLE edc.o_metadata (
    metadata_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entity_name         VARCHAR(64) NOT NULL,
    attribute_name      VARCHAR(128) NOT NULL,
    attribute_value     TEXT,
    description         VARCHAR(255),
    created_date        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (entity_name, attribute_name)
);

-- ============================================================================
-- Indexes to support CRUD, search, and ingestion query patterns
-- ============================================================================
CREATE INDEX idx_site_study               ON edc.o_site(study_id);
CREATE INDEX idx_subject_study             ON edc.o_subject(study_id);
CREATE INDEX idx_subject_site              ON edc.o_subject(site_id);
CREATE INDEX idx_subject_status            ON edc.o_subject(subject_status);
CREATE INDEX idx_subject_enf_subject        ON edc.o_subject_enf(subject_id);
CREATE INDEX idx_study_event_study          ON edc.o_study_event(study_id);
CREATE INDEX idx_study_crf_study            ON edc.o_study_crf(study_id);
CREATE INDEX idx_study_crf_event            ON edc.o_study_crf(study_event_id);
CREATE INDEX idx_study_crf_data_item_crf    ON edc.o_study_crf_data_item(study_crf_id);
CREATE INDEX idx_subject_event_subject      ON edc.o_subject_event(subject_id);
CREATE INDEX idx_subject_event_study_event  ON edc.o_subject_event(study_event_id);
CREATE INDEX idx_subject_crf_data_subject   ON edc.o_subject_crf_data_item(subject_id);
CREATE INDEX idx_subject_crf_data_event     ON edc.o_subject_crf_data_item(subject_event_id);
CREATE INDEX idx_subject_crf_data_item_def  ON edc.o_subject_crf_data_item(study_crf_data_item_id);
CREATE INDEX idx_query_subject              ON edc.o_query(subject_id);
CREATE INDEX idx_query_status               ON edc.o_query(query_status);
CREATE INDEX idx_query_rel_query            ON edc.o_query_crf_data_items_rel(query_id);
CREATE INDEX idx_query_rel_data_item        ON edc.o_query_crf_data_items_rel(subject_crf_data_item_id);
CREATE INDEX idx_audit_subject              ON edc.o_subject_audit_history(subject_id);
CREATE INDEX idx_audit_table_record         ON edc.o_subject_audit_history(table_name, record_id);
CREATE INDEX idx_codelist_name              ON edc.o_codelist_item(codelist_name);
CREATE INDEX idx_protocol_derivation_study  ON edc.o_protocol_derivation(study_id);

-- ============================================================================
-- Generic trigger to keep updated_date current (attach to mutable tables)
-- ============================================================================
CREATE OR REPLACE FUNCTION edc.set_updated_date()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_date = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_study_updated
    BEFORE UPDATE ON edc.o_study
    FOR EACH ROW EXECUTE FUNCTION edc.set_updated_date();

CREATE TRIGGER trg_subject_updated
    BEFORE UPDATE ON edc.o_subject
    FOR EACH ROW EXECUTE FUNCTION edc.set_updated_date();

CREATE TRIGGER trg_subject_event_updated
    BEFORE UPDATE ON edc.o_subject_event
    FOR EACH ROW EXECUTE FUNCTION edc.set_updated_date();

CREATE TRIGGER trg_subject_crf_data_updated
    BEFORE UPDATE ON edc.o_subject_crf_data_item
    FOR EACH ROW EXECUTE FUNCTION edc.set_updated_date();
