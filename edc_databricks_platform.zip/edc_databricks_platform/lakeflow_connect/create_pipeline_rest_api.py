"""
Phase 4 — Create/verify the Lakeflow Connect PostgreSQL ingestion pipeline
programmatically via the Databricks REST API (using the Databricks SDK,
which wraps the same /api/2.0 and /api/2.1 endpoints used by the CLI).

This is the scripted alternative to `databricks bundle deploy` with the YAML
in resources/. Use whichever fits your CI/CD process; both call the same APIs.

Auth: relies on standard Databricks auth resolution (env vars DATABRICKS_HOST /
DATABRICKS_TOKEN, a profile in ~/.databrickscfg, or a service principal).

Usage:
    pip install databricks-sdk
    export DATABRICKS_HOST=https://<workspace>.cloud.databricks.com
    export DATABRICKS_TOKEN=<pat-or-sp-token>
    python create_pipeline_rest_api.py \
        --pg-host <lakebase-host> --pg-port 5432 --pg-database <db> \
        --pg-user databricks_replication --pg-password-secret-scope edc-app-secrets \
        --pg-password-secret-key pg-replication-password \
        --target-catalog digital_cro --target-schema bronze_edc
"""

import argparse
import sys
import time

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.catalog import ConnectionType


def get_or_create_connection(w: WorkspaceClient, name: str, args) -> str:
    for conn in w.connections.list():
        if conn.name == name:
            print(f"Using existing UC connection '{name}' ({conn.connection_id})")
            return conn.connection_id

    conn = w.connections.create(
        name=name,
        connection_type=ConnectionType.POSTGRESQL,
        options={
            "host": args.pg_host,
            "port": str(args.pg_port),
            "user": args.pg_user,
            "password": f"{{{{secrets/{args.pg_password_secret_scope}/{args.pg_password_secret_key}}}}}",
            "dbname": args.pg_database,
            "sslmode": "require",
        },
        comment="EDC Lakebase PostgreSQL source connection for Lakeflow Connect",
    )
    print(f"Created UC connection '{name}' ({conn.connection_id})")
    return conn.connection_id


def get_or_create_gateway(w: WorkspaceClient, name: str, connection_name: str,
                           staging_catalog: str, staging_schema: str) -> str:
    for p in w.pipelines.list_pipelines(filter=f"name LIKE '{name}'"):
        if p.name == name:
            print(f"Using existing gateway pipeline '{name}' ({p.pipeline_id})")
            return p.pipeline_id

    resp = w.pipelines.create(
        name=name,
        continuous=True,
        gateway_definition={
            "connection_name": connection_name,
            "gateway_storage_catalog": staging_catalog,
            "gateway_storage_schema": staging_schema,
            "gateway_storage_name": f"{name}_storage",
        },
    )
    print(f"Created gateway pipeline '{name}' ({resp.pipeline_id})")
    return resp.pipeline_id


def get_or_create_ingestion_pipeline(w: WorkspaceClient, name: str, gateway_id: str,
                                      source_schema: str, target_catalog: str, target_schema: str) -> str:
    for p in w.pipelines.list_pipelines(filter=f"name LIKE '{name}'"):
        if p.name == name:
            print(f"Using existing ingestion pipeline '{name}' ({p.pipeline_id})")
            return p.pipeline_id

    resp = w.pipelines.create(
        name=name,
        catalog=target_catalog,
        target=target_schema,
        continuous=False,
        ingestion_definition={
            "ingestion_gateway_id": gateway_id,
            "objects": [
                {
                    "schema": {
                        "source_schema": source_schema,
                        "destination_catalog": target_catalog,
                        "destination_schema": target_schema,
                    }
                }
            ],
        },
    )
    print(f"Created ingestion pipeline '{name}' ({resp.pipeline_id})")
    return resp.pipeline_id


def start_and_wait(w: WorkspaceClient, pipeline_id: str, timeout_s: int = 600):
    update = w.pipelines.start_update(pipeline_id=pipeline_id)
    print(f"Started update {update.update_id} for pipeline {pipeline_id}")

    deadline = time.time() + timeout_s
    while time.time() < deadline:
        info = w.pipelines.get_update(pipeline_id=pipeline_id, update_id=update.update_id)
        state = info.update.state.value if info.update and info.update.state else "UNKNOWN"
        print(f"  pipeline update state: {state}")
        if state in ("COMPLETED", "FAILED", "CANCELED"):
            return state
        time.sleep(15)
    print("Timed out waiting for pipeline update to finish.")
    return "TIMEOUT"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pg-host", required=True)
    parser.add_argument("--pg-port", default=5432, type=int)
    parser.add_argument("--pg-database", required=True)
    parser.add_argument("--pg-user", default="databricks_replication")
    parser.add_argument("--pg-password-secret-scope", required=True)
    parser.add_argument("--pg-password-secret-key", required=True)
    parser.add_argument("--target-catalog", default="digital_cro")
    parser.add_argument("--target-schema", default="bronze_edc")
    parser.add_argument("--staging-catalog", default=None, help="defaults to target-catalog")
    parser.add_argument("--staging-schema", default="bronze_edc_staging")
    parser.add_argument("--source-schema", default="edc")
    parser.add_argument("--no-run", action="store_true", help="create only, don't trigger a run")
    args = parser.parse_args()
    args.staging_catalog = args.staging_catalog or args.target_catalog

    w = WorkspaceClient()  # picks up DATABRICKS_HOST / DATABRICKS_TOKEN from env

    connection_id = get_or_create_connection(w, "lakebase_edc_connection", args)
    gateway_id = get_or_create_gateway(
        w, "edc-ingestion-gateway", "lakebase_edc_connection", args.staging_catalog, args.staging_schema
    )
    pipeline_id = get_or_create_ingestion_pipeline(
        w, "edc-ingestion-pipeline", gateway_id, args.source_schema, args.target_catalog, args.target_schema
    )

    print("\n--- Summary ---")
    print(f"connection_id: {connection_id}")
    print(f"gateway_pipeline_id: {gateway_id}")
    print(f"ingestion_pipeline_id: {pipeline_id}")
    print("\nSet LAKEFLOW_PIPELINE_ID in databricks_app/app.yaml to the ingestion_pipeline_id above.")

    if not args.no_run:
        # Gateway must be running continuously before the ingestion pipeline is triggered.
        start_and_wait(w, gateway_id, timeout_s=120)
        final_state = start_and_wait(w, pipeline_id)
        sys.exit(0 if final_state == "COMPLETED" else 1)


if __name__ == "__main__":
    main()
