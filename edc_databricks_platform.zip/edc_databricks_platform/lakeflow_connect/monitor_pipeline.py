"""
Lightweight monitoring CLI for the EDC ingestion pipeline.
Prints current pipeline health, latest update state, and recent event-log
entries (errors / data-quality issues) so it can be run from a notebook,
a Databricks Job, or a cron/CI step.

Usage:
    python monitor_pipeline.py --pipeline-id <id>
"""

import argparse

from databricks.sdk import WorkspaceClient


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pipeline-id", required=True)
    parser.add_argument("--event-limit", type=int, default=20)
    args = parser.parse_args()

    w = WorkspaceClient()

    pipeline = w.pipelines.get(pipeline_id=args.pipeline_id)
    print(f"Pipeline: {pipeline.name} ({pipeline.pipeline_id})")
    print(f"State: {pipeline.state}")
    print(f"Health: {getattr(pipeline, 'health', 'N/A')}")

    print("\nRecent updates:")
    for update in list(w.pipelines.list_updates(pipeline_id=args.pipeline_id).updates or [])[:5]:
        print(f"  - {update.update_id}: {update.state.value if update.state else 'UNKNOWN'} "
              f"(creation_time={update.creation_time})")

    print("\nRecent event log entries:")
    events = w.pipelines.list_pipeline_events(pipeline_id=args.pipeline_id, max_results=args.event_limit)
    for event in events:
        level = getattr(event, "level", "INFO")
        message = event.message if hasattr(event, "message") else str(event)
        if level in ("ERROR", "WARN"):
            print(f"  [{level}] {event.timestamp}: {message}")

    print("\nFor detailed audit logs / data-quality metrics, query the pipeline's "
          "event log table in Unity Catalog (configured at pipeline creation time) or "
          "the system.billing.usage table for cost/usage tracking.")


if __name__ == "__main__":
    main()
