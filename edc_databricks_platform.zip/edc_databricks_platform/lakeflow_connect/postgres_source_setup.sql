-- ============================================================================
-- Lakeflow Connect — PostgreSQL source setup (run as an admin on Lakebase)
-- Required once per database before creating the ingestion gateway/pipeline.
-- Ref: Databricks docs "Configure PostgreSQL for ingestion into Databricks"
-- ============================================================================

-- 1. Confirm/enable logical replication (wal_level=logical typically requires
--    a restart; on Lakebase this is managed for you — verify with:)
SHOW wal_level;

-- 2. Dedicated replication user for Databricks (least-privilege, read-only + replication)
CREATE USER databricks_replication WITH PASSWORD 'CHANGE_ME_STRONG_PASSWORD';
GRANT CONNECT ON DATABASE current_database() TO databricks_replication;
GRANT USAGE ON SCHEMA edc TO databricks_replication;
GRANT SELECT ON ALL TABLES IN SCHEMA edc TO databricks_replication;
ALTER DEFAULT PRIVILEGES IN SCHEMA edc GRANT SELECT ON TABLES TO databricks_replication;
ALTER USER databricks_replication WITH REPLICATION;

-- 3. Publication covering every table Lakeflow Connect should replicate
CREATE PUBLICATION databricks_edc_publication FOR TABLES IN SCHEMA edc;

-- 4. Replica identity — tables without a natural full-column requirement use
--    DEFAULT (primary key). All edc.* tables have surrogate PKs, so DEFAULT is fine.
--    (No action needed; included here for completeness / audit.)
-- ALTER TABLE edc.o_subject REPLICA IDENTITY DEFAULT;

-- 5. Verify the replication slot after the gateway is created and started:
-- SELECT slot_name, slot_type, active, restart_lsn
-- FROM pg_replication_slots WHERE slot_name = 'databricks_slot';

-- 6. Verify replica identity across tables:
-- SELECT schemaname, tablename, relreplident
-- FROM pg_tables t JOIN pg_class c ON t.tablename = c.relname
-- WHERE schemaname = 'edc';
