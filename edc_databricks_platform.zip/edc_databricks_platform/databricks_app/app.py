"""
EDC Operations App — Databricks App (Streamlit)

Phase 3 deliverable:
  - CRUD on core EDC entities (Study, Site, Subject)
  - Search across subjects
  - Operational dashboards (enrollment, query status, data entry status)
  - A button to trigger the Lakeflow Connect ingestion pipeline via the
    Databricks REST API, plus a live pipeline status panel

Deploy as a Databricks App:
  1. `databricks apps create edc-ops-app`
  2. Attach a Lakebase Postgres database resource to the app (Settings > Resources)
     so PGHOST/PGPORT/PGDATABASE/PGUSER/PGPASSWORD are injected automatically.
  3. `databricks sync . /Workspace/Users/<you>/edc-ops-app`
  4. `databricks apps deploy edc-ops-app --source-code-path /Workspace/Users/<you>/edc-ops-app`
"""

import os

import pandas as pd
import plotly.express as px
import requests
import streamlit as st

from db import execute, query_df

st.set_page_config(page_title="EDC Operations", layout="wide")

DATABRICKS_HOST = os.environ.get("DATABRICKS_HOST", "")
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN", "")  # injected via app.yaml env / secret scope
LAKEFLOW_PIPELINE_ID = os.environ.get("LAKEFLOW_PIPELINE_ID", "")


# ---------------------------------------------------------------------------
# Sidebar navigation
# ---------------------------------------------------------------------------
st.sidebar.title("EDC Operations")
page = st.sidebar.radio(
    "Navigate",
    ["Dashboard", "Studies", "Sites", "Subjects", "Queries", "Ingestion"],
)


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
if page == "Dashboard":
    st.title("Study Operations Dashboard")

    studies = query_df("SELECT study_id, study_name, study_code FROM edc.o_study ORDER BY study_name")
    if studies.empty:
        st.info("No studies found yet. Run the synthetic data generator or add a study under 'Studies'.")
    else:
        col1, col2, col3, col4 = st.columns(4)
        counts = query_df("""
            SELECT
              (SELECT COUNT(*) FROM edc.o_study)   AS studies,
              (SELECT COUNT(*) FROM edc.o_site)    AS sites,
              (SELECT COUNT(*) FROM edc.o_subject) AS subjects,
              (SELECT COUNT(*) FROM edc.o_query WHERE query_status = 'OPEN') AS open_queries
        """).iloc[0]
        col1.metric("Studies", int(counts["studies"]))
        col2.metric("Sites", int(counts["sites"]))
        col3.metric("Subjects", int(counts["subjects"]))
        col4.metric("Open Queries", int(counts["open_queries"]))

        st.subheader("Enrollment by Site")
        enroll = query_df("""
            SELECT s.site_name, COUNT(sub.subject_id) AS subject_count
            FROM edc.o_site s
            LEFT JOIN edc.o_subject sub ON sub.site_id = s.site_id
            GROUP BY s.site_name ORDER BY subject_count DESC
        """)
        if not enroll.empty:
            st.plotly_chart(px.bar(enroll, x="site_name", y="subject_count"), use_container_width=True)

        col_a, col_b = st.columns(2)
        with col_a:
            st.subheader("Subject Status Breakdown")
            status_df = query_df("""
                SELECT subject_status, COUNT(*) AS n FROM edc.o_subject GROUP BY subject_status
            """)
            if not status_df.empty:
                st.plotly_chart(px.pie(status_df, names="subject_status", values="n"), use_container_width=True)

        with col_b:
            st.subheader("Query Status")
            query_status_df = query_df("""
                SELECT query_status, COUNT(*) AS n FROM edc.o_query GROUP BY query_status
            """)
            if not query_status_df.empty:
                st.plotly_chart(px.pie(query_status_df, names="query_status", values="n"), use_container_width=True)


# ---------------------------------------------------------------------------
# Studies CRUD
# ---------------------------------------------------------------------------
elif page == "Studies":
    st.title("Studies")

    with st.expander("+ Add new study"):
        with st.form("add_study"):
            c1, c2 = st.columns(2)
            study_code = c1.text_input("Study code*")
            protocol_number = c2.text_input("Protocol number*")
            study_name = st.text_input("Study name*")
            sponsor_name = st.text_input("Sponsor")
            phase = st.selectbox("Phase", ["I", "II", "III", "IV", "N/A"])
            therapeutic_area = st.text_input("Therapeutic area")
            submitted = st.form_submit_button("Create study")
            if submitted:
                if not (study_code and protocol_number and study_name):
                    st.error("Study code, protocol number, and study name are required.")
                else:
                    execute(
                        """INSERT INTO edc.o_study
                           (study_code, protocol_number, study_name, sponsor_name, phase, therapeutic_area)
                           VALUES (%s,%s,%s,%s,%s,%s)""",
                        (study_code, protocol_number, study_name, sponsor_name, phase, therapeutic_area),
                    )
                    st.success(f"Study '{study_name}' created.")
                    st.rerun()

    df = query_df("SELECT * FROM edc.o_study ORDER BY created_date DESC")
    st.dataframe(df, use_container_width=True)

    if not df.empty:
        st.subheader("Update / delete a study")
        sel = st.selectbox("Select study", df["study_id"], format_func=lambda i: df[df.study_id == i].study_name.values[0])
        row = df[df.study_id == sel].iloc[0]
        new_status = st.selectbox(
            "Status", ["PLANNED", "ACTIVE", "SUSPENDED", "COMPLETED", "TERMINATED"],
            index=["PLANNED", "ACTIVE", "SUSPENDED", "COMPLETED", "TERMINATED"].index(row["study_status"]),
        )
        c1, c2 = st.columns(2)
        if c1.button("Save status"):
            execute("UPDATE edc.o_study SET study_status=%s WHERE study_id=%s", (new_status, int(sel)))
            st.success("Updated.")
            st.rerun()
        if c2.button("Delete study", type="secondary"):
            execute("DELETE FROM edc.o_study WHERE study_id=%s", (int(sel),))
            st.warning("Study deleted (cascades to sites/subjects).")
            st.rerun()


# ---------------------------------------------------------------------------
# Sites CRUD
# ---------------------------------------------------------------------------
elif page == "Sites":
    st.title("Sites")
    studies = query_df("SELECT study_id, study_name FROM edc.o_study ORDER BY study_name")
    if studies.empty:
        st.info("Create a study first.")
    else:
        with st.expander("+ Add new site"):
            with st.form("add_site"):
                study_id = st.selectbox("Study", studies["study_id"],
                                         format_func=lambda i: studies[studies.study_id == i].study_name.values[0])
                site_number = st.text_input("Site number*")
                site_name = st.text_input("Site name*")
                pi = st.text_input("Principal investigator")
                country = st.text_input("Country")
                city = st.text_input("City")
                submitted = st.form_submit_button("Create site")
                if submitted:
                    if not (site_number and site_name):
                        st.error("Site number and site name are required.")
                    else:
                        execute(
                            """INSERT INTO edc.o_site (study_id, site_number, site_name, principal_investigator, country, city)
                               VALUES (%s,%s,%s,%s,%s,%s)""",
                            (int(study_id), site_number, site_name, pi, country, city),
                        )
                        st.success(f"Site '{site_name}' created.")
                        st.rerun()

        df = query_df("""
            SELECT s.*, st.study_name FROM edc.o_site s
            JOIN edc.o_study st ON st.study_id = s.study_id
            ORDER BY s.created_date DESC
        """)
        st.dataframe(df, use_container_width=True)


# ---------------------------------------------------------------------------
# Subjects CRUD + Search
# ---------------------------------------------------------------------------
elif page == "Subjects":
    st.title("Subjects")

    search = st.text_input("Search by subject number, site, or status")
    base_sql = """
        SELECT sub.subject_id, sub.subject_number, st.study_name, si.site_name,
               sub.subject_status, sub.enrollment_date, sub.randomization_arm
        FROM edc.o_subject sub
        JOIN edc.o_study st ON st.study_id = sub.study_id
        JOIN edc.o_site si ON si.site_id = sub.site_id
    """
    if search:
        df = query_df(
            base_sql + """
            WHERE sub.subject_number ILIKE %(term)s
               OR si.site_name ILIKE %(term)s
               OR sub.subject_status ILIKE %(term)s
            ORDER BY sub.subject_id DESC
            """,
            params={"term": f"%{search}%"},
        )
    else:
        df = query_df(base_sql + " ORDER BY sub.subject_id DESC LIMIT 500")

    st.dataframe(df, use_container_width=True)

    sites = query_df("""
        SELECT si.site_id, si.site_name, si.study_id FROM edc.o_site si
    """)
    with st.expander("+ Add new subject"):
        with st.form("add_subject"):
            site_id = st.selectbox("Site", sites["site_id"],
                                    format_func=lambda i: sites[sites.site_id == i].site_name.values[0])
            subject_number = st.text_input("Subject number*")
            sex = st.selectbox("Sex", ["M", "F", "U"])
            status = st.selectbox("Status", ["SCREENING", "ENROLLED", "RANDOMIZED", "COMPLETED", "WITHDRAWN", "SCREEN_FAILED"])
            submitted = st.form_submit_button("Create subject")
            if submitted:
                if not subject_number:
                    st.error("Subject number is required.")
                else:
                    study_id = int(sites[sites.site_id == site_id].study_id.values[0])
                    execute(
                        """INSERT INTO edc.o_subject (study_id, site_id, subject_number, sex, subject_status)
                           VALUES (%s,%s,%s,%s,%s)""",
                        (study_id, int(site_id), subject_number, sex, status),
                    )
                    st.success(f"Subject '{subject_number}' created.")
                    st.rerun()

    if not df.empty:
        st.subheader("Update subject status")
        sel = st.selectbox("Select subject", df["subject_id"],
                            format_func=lambda i: df[df.subject_id == i].subject_number.values[0])
        new_status = st.selectbox(
            "New status",
            ["SCREENING", "SCREEN_FAILED", "ENROLLED", "RANDOMIZED", "COMPLETED", "WITHDRAWN", "DISCONTINUED"],
        )
        if st.button("Save subject status"):
            execute("UPDATE edc.o_subject SET subject_status=%s WHERE subject_id=%s", (new_status, int(sel)))
            execute(
                """INSERT INTO edc.o_subject_audit_history
                   (subject_id, table_name, record_id, field_name, new_value, action_type, changed_by, reason_for_change)
                   VALUES (%s,'o_subject',%s,'subject_status',%s,'UPDATE',%s,'Manual status update via app')""",
                (int(sel), int(sel), new_status, "app_user"),
            )
            st.success("Subject updated and audit entry recorded.")
            st.rerun()


# ---------------------------------------------------------------------------
# Queries
# ---------------------------------------------------------------------------
elif page == "Queries":
    st.title("Data Management Queries")
    df = query_df("""
        SELECT q.query_id, sub.subject_number, q.query_text, q.query_status, q.priority,
               q.opened_by, q.opened_date, q.closed_by, q.closed_date
        FROM edc.o_query q
        JOIN edc.o_subject sub ON sub.subject_id = q.subject_id
        ORDER BY q.opened_date DESC
    """)
    status_filter = st.multiselect("Filter by status", ["OPEN", "ANSWERED", "CLOSED", "CANCELLED"],
                                    default=["OPEN", "ANSWERED"])
    if status_filter:
        df = df[df.query_status.isin(status_filter)]
    st.dataframe(df, use_container_width=True)

    if not df.empty:
        st.subheader("Resolve a query")
        sel = st.selectbox("Select query", df["query_id"])
        new_status = st.selectbox("New status", ["OPEN", "ANSWERED", "CLOSED", "CANCELLED"])
        if st.button("Update query"):
            execute(
                """UPDATE edc.o_query SET query_status=%s,
                   closed_date = CASE WHEN %s = 'CLOSED' THEN now() ELSE closed_date END,
                   closed_by = CASE WHEN %s = 'CLOSED' THEN %s ELSE closed_by END
                   WHERE query_id=%s""",
                (new_status, new_status, new_status, "app_user", int(sel)),
            )
            st.success("Query updated.")
            st.rerun()


# ---------------------------------------------------------------------------
# Ingestion trigger (Lakeflow Connect)
# ---------------------------------------------------------------------------
elif page == "Ingestion":
    st.title("Lakeflow Connect Ingestion")
    st.write(
        "Triggers the Lakeflow Connect pipeline that replicates Lakebase PostgreSQL "
        "into the Unity Catalog Bronze layer (`digital_cro.bronze_edc`)."
    )

    if not (DATABRICKS_HOST and DATABRICKS_TOKEN and LAKEFLOW_PIPELINE_ID):
        st.warning(
            "Set DATABRICKS_HOST, DATABRICKS_TOKEN (via a Databricks secret), and "
            "LAKEFLOW_PIPELINE_ID as app environment variables to enable this page. "
            "See app.yaml and lakeflow_connect/create_pipeline_rest_api.py."
        )
    else:
        headers = {"Authorization": f"Bearer {DATABRICKS_TOKEN}"}

        col1, col2 = st.columns(2)
        if col1.button("🚀 Trigger ingestion run now"):
            resp = requests.post(
                f"{DATABRICKS_HOST}/api/2.0/pipelines/{LAKEFLOW_PIPELINE_ID}/updates",
                headers=headers,
                json={"full_refresh": False},
                timeout=30,
            )
            if resp.ok:
                st.success(f"Pipeline update triggered: {resp.json().get('update_id')}")
            else:
                st.error(f"Failed to trigger pipeline: {resp.status_code} {resp.text}")

        if col2.button("🔄 Refresh pipeline status"):
            st.rerun()

        resp = requests.get(
            f"{DATABRICKS_HOST}/api/2.0/pipelines/{LAKEFLOW_PIPELINE_ID}",
            headers=headers,
            timeout=30,
        )
        if resp.ok:
            pdata = resp.json()
            st.subheader("Pipeline state")
            st.json({
                "pipeline_id": pdata.get("pipeline_id"),
                "name": pdata.get("name"),
                "state": pdata.get("state"),
                "latest_updates": pdata.get("latest_updates", [])[:5],
            })
        else:
            st.error(f"Could not fetch pipeline status: {resp.status_code} {resp.text}")
