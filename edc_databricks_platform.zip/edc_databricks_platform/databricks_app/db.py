"""
Connection helper for the EDC Databricks App.

Reads Lakebase PostgreSQL connection details from environment variables that
are injected by Databricks Apps when the app is bound to a Lakebase database
resource (Settings > App resources > Database instance). Falls back to plain
env vars for local development.
"""

import os
from contextlib import contextmanager

import pandas as pd
import psycopg2
import psycopg2.extras


def _conn_params():
    return dict(
        host=os.environ.get("PGHOST", os.environ.get("LAKEBASE_HOST")),
        port=os.environ.get("PGPORT", os.environ.get("LAKEBASE_PORT", "5432")),
        dbname=os.environ.get("PGDATABASE", os.environ.get("LAKEBASE_DB")),
        user=os.environ.get("PGUSER", os.environ.get("LAKEBASE_USER")),
        password=os.environ.get("PGPASSWORD", os.environ.get("LAKEBASE_PASSWORD")),
        sslmode=os.environ.get("PGSSLMODE", "require"),
    )


@contextmanager
def get_conn():
    conn = psycopg2.connect(**_conn_params())
    try:
        yield conn
    finally:
        conn.close()


def query_df(sql, params=None):
    """Run a SELECT and return a pandas DataFrame."""
    with get_conn() as conn:
        return pd.read_sql(sql, conn, params=params)


def execute(sql, params=None, returning=False):
    """Run an INSERT/UPDATE/DELETE. Returns the RETURNING value if requested."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params or ())
            result = cur.fetchone()[0] if returning else None
        conn.commit()
        return result
